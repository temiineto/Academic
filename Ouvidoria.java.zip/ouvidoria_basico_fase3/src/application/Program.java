package application;

import java.sql.Connection;
import java.util.Scanner;

import db.DB;
import entities.Elogio;
import entities.Manifestacao;
import entities.Pessoa;
import entities.Reclamacao;
import entities.Sugestao;

public class Program {
    public static void main(String[] args) {
        Connection con = DB.getConnection();
        Scanner sc = new Scanner(System.in);
        System.out.println("Você está no Sistema Ouvidora da UNIFACISA!\n\nSeu Feedback é muito importante para o nosso crescimento =)\n");

        int opt;

        do {
            System.out.println("\n*********** MENU DE OPÇÕES ***********\n\n1 - Inserir manifestação;\n2 - Listar todas as manifestações já cadastradas;\n3 - Apagar alguma manifestação;\n4 - Sair.\n\nDigite a opção desejada:");
            opt = sc.nextInt();
            sc.nextLine();

            switch (opt) {
                case 1:
                    System.out.print("Digite seu nome: ");
                    String nome = sc.nextLine();
                    System.out.print("Digite sua matrícula: ");
                    int matricula = sc.nextInt();
                    sc.nextLine();
                    int tipoManifestacao;
                    do {
                        System.out.print("\nDigite:\n 1 - Para fazer um ELOGIO;\n 2 - Para fazer uma RECLAMAÇÃO;\n 3 - Para fazer uma SUGESTÃO. ");
                        tipoManifestacao = sc.nextInt();
                        sc.nextLine();
                        if (tipoManifestacao < 1 || tipoManifestacao > 3) {
                            System.out.println("\nDigite uma opção válida!\n");
                        }
                    } while (tipoManifestacao < 1 || tipoManifestacao > 3);
                 
                    Pessoa p = new Pessoa (nome, matricula);
                    System.out.print("\nO que você gostaria de nos falar? \n");
                    String texto = sc.nextLine(); 
                    if (tipoManifestacao == 1) {
                    	Manifestacao e = new Elogio(p, texto);
                    	e.inserirManifestacao (con);
                    	System.out.println("\nElogio cadastrado com sucesso!");       
                    }
                    
                    if (tipoManifestacao == 2) {
	                    Manifestacao r = new Reclamacao(p, texto);
	                    r.inserirManifestacao (con);
	                    System.out.println("\nReclamação cadastrada com sucesso!");
	                    }
	                
                    if (tipoManifestacao == 3){
	                    Manifestacao s = new Sugestao(p, texto);
	                    s.inserirManifestacao (con);
	                    System.out.println("\nSugestão cadastrada com sucesso!");
	                    } 
                    
                    
                    break;
                case 2:
                    System.out.println("\n*********** LISTA DE MANIFESTAÇÕES ***********\n");
                    Manifestacao.listarManifestacoes(con);
                    System.out.println();
                    break;
                case 3:
                    System.out.print("\nDigite o ID da manifestação que deseja apagar: ");
                    int idManifestacao = sc.nextInt();
                    sc.nextLine();
                    Manifestacao.apagarManifestacao(con, idManifestacao);
                    break;
                case 4:
                    System.out.println("\nObrigado pelo seu feedback, iremos analisar suas demandas e respondê-las o mais rápido possível!\n");
                    break;
                default:
                    System.out.println("\nDigite uma opção válida!\n");
            }
        } while (opt != 4);

        sc.close();
        DB.closeConnection(con);
    }
}