package entities;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Manifestacao {
	private int id;

	private String tipoManifestacao;

	private String texto;
	Pessoa pessoa;

	public Manifestacao(Pessoa pessoa, String texto) {

		this.pessoa = pessoa;
		this.texto = texto;
	}

	public Manifestacao(String nome, int matricula, int tipoManifestacao2, String texto2) {
		// TODO Auto-generated constructor stub
	}

	public String getTipoManifestacao() {
		return tipoManifestacao;
	}

	public String getTexto() {
		return texto;
	}

	public void inserirManifestacao(Connection con) {
		String sql = "INSERT INTO pessoa (nome, matricula, tipo_manifestacao, texto) VALUES (?, ?, ?, ?)";

		try (PreparedStatement s = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
			s.setString(1, this.pessoa.getNome());
			s.setInt(2, this.pessoa.getMatricula());
			s.setString(3, tipoManifestacao);
			s.setString(4, texto);

			int update = s.executeUpdate();

			if (update > 0) {

				ResultSet result = s.getGeneratedKeys();
				if (result.next()) {
					setId(result.getInt(1));
				}
			} else {
				System.out.println("\nFalha ao registrar a manifestação.\n");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static void listarManifestacoes(Connection con) {
		String sql = "SELECT * FROM pessoa";

		try {
			Statement s = con.createStatement();
			ResultSet result = s.executeQuery(sql);

			while (result.next()) {
				int id = result.getInt("id");
				String nome = result.getString("nome");
				int matricula = result.getInt("matricula");
				String tipoManifestacao = result.getString("tipo_manifestacao");
				String texto = result.getString("texto");

				System.out.printf("ID: %d, Nome: %s, Matrícula: %d, Tipo: %s, Texto: %s%n", id, nome, matricula,
						tipoManifestacao, texto);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static void apagarManifestacao(Connection con, int id) {
		String sql = "DELETE FROM pessoa WHERE id = ?";

		try (PreparedStatement s = con.prepareStatement(sql)) {
			s.setInt(1, id);

			int update = s.executeUpdate();

			if (update > 0) {
				System.out.println("Manifestação apagada com sucesso!");
			} else {
				System.out.println("Nenhuma manifestação encontrada com o ID fornecido.");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setTipoManifestacao(String tipoManifestacao) {
		this.tipoManifestacao = tipoManifestacao;
	}

}
