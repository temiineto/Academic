package entities;

public class Elogio extends Manifestacao {

	public Elogio(Pessoa pessoa, String texto) {
		super(pessoa, texto);
		this.setTipoManifestacao("Elogio");
		// TODO Auto-generated constructor stub
	}
	
}
