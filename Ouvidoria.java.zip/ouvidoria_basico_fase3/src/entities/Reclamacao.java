package entities;

public class Reclamacao extends Manifestacao {

	public Reclamacao(Pessoa pessoa, String texto) {
		super(pessoa, texto);
		// TODO Auto-generated constructor stub
	}

}
