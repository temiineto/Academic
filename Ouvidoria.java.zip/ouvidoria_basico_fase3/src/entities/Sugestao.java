package entities;

public class Sugestao extends Manifestacao{

	public Sugestao(Pessoa pessoa, String texto) {
		super(pessoa, texto);
		// TODO Auto-generated constructor stub
	}
	
	
}
