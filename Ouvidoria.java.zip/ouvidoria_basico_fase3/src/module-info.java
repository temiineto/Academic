/**
 * 
 */
/**
 * @author Temístocles Maciel
 *
 */
module jdbc {
	requires java.sql;
}